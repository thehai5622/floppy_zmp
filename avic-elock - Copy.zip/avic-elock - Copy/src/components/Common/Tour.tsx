import { Tour, TourProps } from "antd";

const CommonTour = (props: TourProps) => {
  return <Tour {...props} className={`avic-tour ${props?.className || ""}`} />;
};

export default CommonTour;
