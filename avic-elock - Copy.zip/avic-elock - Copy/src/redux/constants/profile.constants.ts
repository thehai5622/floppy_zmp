export const SAVE_PROFILE = "SAVE_PROFILE";
