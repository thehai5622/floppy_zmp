import * as Constants from '../constants/positionSelected.constants';

const initialState = {
  positionSelected: []
};

// eslint-disable-next-line import/no-anonymous-default-export
export default function (state = initialState, action:any) {
  switch (action.type) {
    case Constants.SAVE_POSITION_SELECTED:
      return {
        ...state,
        positionSelected: action?.payload,
      };
    default:
      return state
  }
}