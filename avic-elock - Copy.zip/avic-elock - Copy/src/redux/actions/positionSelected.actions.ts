import * as Constants from '../constants/positionSelected.constants';

export const savePositionSelected = (payload:any) => {
    return {
        type: Constants.SAVE_POSITION_SELECTED,
        payload: payload
    }
}

