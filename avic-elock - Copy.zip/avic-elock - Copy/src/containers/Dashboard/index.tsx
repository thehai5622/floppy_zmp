import background from "../../resources/images/dashboard/home.png";

function DashBoard() {
  return (
    <div className="dashboard-container" style={{ backgroundImage: `url(${background})` }}></div>
  );
}

export default DashBoard;
