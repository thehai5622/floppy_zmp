import { createContext } from "react";

type DataUpdateContextType = {
    dataUpdate: {[key: string]: any}
    setDataUpdate: React.Dispatch<React.SetStateAction<{[key: string]: any}>>
}

const DataUpdateContext = createContext<DataUpdateContextType>({} as DataUpdateContextType)

export default DataUpdateContext