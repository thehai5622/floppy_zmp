export interface IDriverAddModalProps {
    dataDetail?: any;
    visible: boolean;
    handleOk: () => void;
    handleCancel: () => void;
  }
  