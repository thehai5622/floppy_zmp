export interface IDriverAddData {
    name: string;
    uniqueid: string;
}

export interface IDriverDetailData {
    id: number
    isDelete: number
    createdDate: number
    modifiedDate: number
    createBy: string
    modifiedBy: string
    createdDateStr: string
    modifiedDateStr: string
    createById: number
    modifiedById: number
    name: string
    uniqueid: string
    countUsed: number
}

export interface IDriverAddModalProps {
    dataDetail?: IDriverDetailData;
    visible: boolean;
    handleOk: () => void;
    handleCancel: () => void;
}
