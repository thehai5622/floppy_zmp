import { ItemType } from "antd/es/breadcrumb/Breadcrumb";
import { ReactNode } from "react";

export interface ISidebarItemType {
  label: JSX.Element | string;
  key: string;
  icon?: JSX.Element;
  hidden?: undefined | boolean;
  children?: ISidebarItemType[] | undefined;
}

export interface ILayoutProps {
  children: ReactNode;
}

export interface IBreadcrumbItemType {
  title: string;
  href?: string;
  add?: { title: string; href?: string };
  detail?: { title: string; href?: string };
  history?: { title: string; href?: string };
}

export interface IConfigSideBar {
  selectedKeys: string;
  openKeys: string;
  arrMenus: ISidebarItemType[];
  breadcrumbItems: ItemType[];
}

export interface ISideBarProps {
  config: IConfigSideBar;
}
