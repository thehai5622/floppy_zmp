export interface IVendorManagementAddData {
  address: string;
  companyName: string;
  productType: string;
  status: number;
  taxCode: string;
  communeId: number;
  districtId: number;
  provinceId: number;
}

export interface IVendorManagementDetailData {
  id: number;
  isDelete: number;
  createdDate: number;
  modifiedDate: number;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  taxCode: string;
  companyName: string;
  productType: string;
  address: string;
  status: number;
  vendorCode: string;
  communeId: number;
  districtId: number;
  lat: number;
  lon: number;
  provinceId: number;
}

export interface IVendorTabsProps {
  detailVendor: IVendorManagementDetailData | undefined;
}
