export interface ICommonSearchParams {
  search?: string;
  page?: number;
  size?: number;
  sortBy?: string;
  sortType?: string;
}

// export interface ICommonResponse<T = any> {
//   success: boolean;
//   code: number;
//   message: string;
//   data: T | T[];
//   path: string;
//   time: number;
// }

export interface ICommonResponsePaging<T = any> {
  content: T[];
  pageable: {
    sort: {
      empty: boolean;
      sorted: boolean;
      unsorted: boolean;
    };
    offset: number;
    pageNumber: number;
    pageSize: number;
    paged: boolean;
    unpaged: boolean;
  };
  totalPages: number;
  totalElements: number;
  last: boolean;
  number: number;
  sort: {
    empty: boolean;
    sorted: boolean;
    unsorted: boolean;
  };
  size: number;
  numberOfElements: number;
  first: boolean;
  empty: boolean;
}

export interface IUseQueryResponse {
  query: URLSearchParams;
  params: {
    [x: string]: string;
  };
  search: string;
}
export interface IUseWindowSizeResponse {
  width: number;
  height: number;
}

export interface ICommonSelectDataType {
  value: number | string;
  label: string;
  type?: "primary" | "info" | "success" | "danger" | "warning" | "default" | undefined;
}

export interface IMapComponent {
  isShowSearch?: boolean;
  isShowCurrentBtn?: boolean;
  children?: React.ReactNode;
}

export interface ILANGUAGE_OPTIONS_TYPE {
  value: string;
  label: string;
  icon: string;
}

export interface ISearchBoxProps {
  getData: any;
  componentPath: string;
}

export interface IPlaceSelectType {
  description: string;
  id: number;
  name: string;
  parentId: number;
  type: string;
}
