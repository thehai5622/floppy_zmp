import { IVendorManagementDetailData } from "./vendorManagement";

export interface ILockAddData {
  uniqueid: string;
}
export interface ILockDetailData {
  id: number;
  isDelete: number;
  createdDate: number;
  modifiedDate: number;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  name: string;
  tenFisrtOfImei: string;
  uniqueid: string;
  fullImei: string;
  lastupdate: number;
  positionid: number;
  groupid: number;
  attributes: any;
  phone: string;
  model: string;
  contact: string;
  category: any;
  disabled: boolean;
  status: string;
  statusWork: number;
  geofenceids: any;
  expirationtime: any;
  motionstate: any;
  motiontime: any;
  motiondistance: any;
  overspeedstate: any;
  overspeedtime: any;
  overspeedgeofenceid: any;
  motionstreak: any;
  driverName: string;
  plateNumber: string;
  companyName: string;
  source: string;
  tcPosition: any;
  countUse: number;
  vendor: IVendorManagementDetailData;
  note: string;
  statusConvert: number;
}

export interface ILockTabProps {
  dataDetail: ILockDetailData | undefined;
}

export interface IDecentralizationVendorUseLock {
  lockId: number;
  source: string;
  type: number; //Gán/gỡ khóa cho công ty quản lý type 1 = gắn, 2 = gỡ
  note?: string;
}

export interface IDecentralizationAccountUseLock {
  lockId: number;
  userIds: number[];
}

export interface IDecentralizeKeyUsageModalProps {
  visable: boolean;
  handleOk: () => void;
  handleCancel: () => void;
  detailLock: ILockDetailData | undefined;
}

export interface ILockCreateModalProps {
  visible: boolean;
  handleOk: () => void;
  handleCancel: () => void;
}

export interface IHistoryLockDetailData {
  id: number;
  isDelete: number;
  createdDate: number;
  modifiedDate: number;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  lockId: number;
  registrationCarId: number;
  plateNumber: string;
  startPoint: string;
  endPoint: string;
  useTime: number;
  vendorDeleted: any;
  source: string;
}
