export interface ILocationAddModalProps {
  visible: boolean;
  handleOk: () => void;
  handleCancel: () => void;
  newLocation?: any;
  dataDetail?: ILocationDetailData;
}
export interface ILocationControlProps {
  listLocation: ILocationDetailData[];
  currentLocation?: ILocationDetailData;
  getData: any;
}

export interface ILocationDetailData {
  address: string;
  createBy: string;
  createById: number;
  createdDate: string;
  createdDateStr: string;
  id: number;
  isDelete: number;
  latitude: number;
  longitude: number;
  modifiedBy: string;
  modifiedById: number;
  modifiedDate: string;
  modifiedDateStr: string;
  name: string;
  source: string;
  status: number;
  type: number;
  positionCode?: string;
  factoryAreaId: string
  areaOrder: string;
}

export interface ILocationAddData {
  address: string;
  latitude: number;
  longitude: number;
  name: string;
  status: number;
  type: number;
}
