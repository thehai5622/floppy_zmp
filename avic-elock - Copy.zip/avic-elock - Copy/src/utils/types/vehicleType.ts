export interface IVehicleTypeAddData {
  name: string;
  timeForAllow: number;
  isInternalCar: number;
  status: number;
}

export interface IVehicleTypeDetailData {
  id: number;
  isDelete: number;
  createdDate: number;
  modifiedDate: number;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  name: string;
  timeForAllow: number;
  status: number;
  isInternalCar: number;
  type: number;
  timeForAllowStr: string;
}

export interface IVehicleTypeAddModalProps {
  dataDetail?: IVehicleTypeDetailData;
  visible: boolean;
  handleOk: () => void;
  handleCancel: () => void;
}
