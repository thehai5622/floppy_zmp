import { IGroupDetailData } from "./groupManagement";

export interface IAccountAddData {
  avatar?: string;
  email: string;
  groups: { id: number }[];
  name: string;
  password: string;
  phone: string;
  source?: string;
  status: number;
  username: string;
}

export interface IAccountDetailData {
  id?: number;
  isDelete?: number;
  createdDate?: number;
  modifiedDate?: number;
  createBy?: string;
  modifiedBy?: string;
  createdDateStr?: string;
  modifiedDateStr?: string;
  createById?: number;
  modifiedById?: number;
  username?: string;
  phone?: string;
  name?: string;
  company?: number;
  status?: number;
  email?: string;
  source?: string;
  groups?: IGroupDetailData[];
}

export interface LoginData {
  password: string;
  username: string;
}

export interface ChangePasswordData {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
  userId: number | undefined;
}
