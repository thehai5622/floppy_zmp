import { FormInstance } from "antd";
import { Dispatch, SetStateAction } from "react";
import { ILocationDetailData } from "./locationCategory";
import { ILockDetailData } from "./lockManagement";
import { IVehicleTypeDetailData } from "./vehicleType";
import { IVendorManagementDetailData } from "./vendorManagement";

export interface ICompanyDeliverySitesAddData {
  cdsId: number;
  id: number;
  key: string;
  index: number;
  name: string;
  disabled: boolean;
  unlockTime?: number;
  lockTime?: number;
  receiptNumber: number
  receiptUpdateTime: string
}

export interface IArea {
  id: number
  isDelete: number
  createdDate: string | null
  modifiedDate: string | null
  createBy: string
  modifiedBy: string
  createdDateStr: string
  modifiedDateStr: string
  createById: number
  modifiedById: number
  name: string
  status: boolean
}

export interface ICompanyDeliverySites {
  categoryLock: Partial<ILockDetailData>;
  categoryPosition: Partial<ILocationDetailData>;
  createBy: string;
  createById: number;
  createdDate: string;
  createdDateStr: string;
  id: number;
  isDelete: number;
  isViolation: number;
  lockStatus: number;
  lockTime: string;
  modifiedBy: string;
  modifiedById: number;
  modifiedDate: string;
  modifiedDateStr: string;
  note: string;
  orderNumber: number;
  unlockTime: string;
  unlockUser: any;
  // Sửa thêm trường dữ liệu
  receiptNumber: number
  receiptUpdateTime: string
}

export interface IRegisterCarLocks {
  categoryLock: Partial<ILockDetailData>;
  createBy: string;
  createById: number;
  createdDate: string;
  createdDateStr: string;
  id: number;
  isDelete: number;
  modifiedBy: string;
  modifiedById: number;
  modifiedDate: string;
  modifiedDateStr: string;
}

export interface IJourneyAddData {
  categoryCar: Partial<IVehicleTypeDetailData>;
  categoryLock: Partial<ILockDetailData>;
  companyDeliverySites: Partial<ICompanyDeliverySites>[];
  note: string;
  optionDelivery: number;
  plateNumber: string;
  source: string;
  status: number;
  totalDoor: number;
  totalViolation: number;
  companyName: string;
}

export interface IJourneyDetailData {
  id: number;
  isDelete: number;
  createdDate: number;
  modifiedDate: number;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  plateNumber: string;
  categoryCar: Partial<IVehicleTypeDetailData>;
  categoryLock: Partial<ILockDetailData>;
  gateIn: string;
  dateIn: number;
  status: number;
  dateOut: number;
  note: string;
  // Thêm registerFactoryArea
  registerFactoryArea: IRegisterFactoryArea[]
  companyDeliverySites: Partial<ICompanyDeliverySites>[];
  registerCarLocks: Partial<IRegisterCarLocks>[];
  source: string;
  totalDoor: number;
  driverIdentity: string;
  driverName: string;
  optionDelivery: number;
  totalDelivery: number;
  dateStartDelivery: number;
  dateCheckin: number;
  dateCheckout: number;
  dateCompleteDelivery: number;
  dateInStr: string;
  statusStr: string;
  gateInStr: null;
  sourceStr: string;
  vendor?: IVendorManagementDetailData;
  gpsInfo?: any;
  companyName: string;
  moveDelaySeconds: number
  // Thêm tổng số lần vi phạm
  totalViolation: number;
}

// Thêm registerFactoryArea
export interface IRegisterFactoryArea {
  id: number
  isDelete: number
  createdDate: any
  modifiedDate: any
  createBy: string
  modifiedBy: string
  createdDateStr: string
  modifiedDateStr: string
  createById: number
  modifiedById: number
  factoryArea: FactoryArea
  areaOrder: number
  dateCheckin: any
  dateCheckout: any
  totalReceipts: number
  status: number
  companyDeliverySites: ICompanyDeliverySites[]
}

export interface FactoryArea {
  id: number
  isDelete: number
  createdDate: any
  modifiedDate: any
  createBy: string
  modifiedBy: string
  createdDateStr: string
  modifiedDateStr: string
  createById: number
  modifiedById: number
  name: string
  status: boolean
}
// </>

export interface IOpenLockData {
  deviceId: number[];
  deviceIds: number[];
  positionId: number;
  registerCarId: number;
  source: string;
}

export interface IReportBrokenLock {
  lockId: number;
  registrationCarId: number;
}

export interface IDismantlingLock {
  registerCarId: number;
  deviceId: number;
  source: string;
  action: string;
}

export interface IJourneyTabProps {
  detailData: IJourneyDetailData;
  form: FormInstance<any>;
  isEditing: boolean;
}

export interface IOperateControlProps {
  listJourney: IJourneyDetailData[];
  currentJourney: IJourneyDetailData | undefined;
  setCurrentJourney: Dispatch<SetStateAction<IJourneyDetailData | undefined>>;
}

export interface IGPSData {
  lat: number;
  lon: number;
  registrationCarId: number;
  plateNumber: string;
  timeSend: number;
  deviceId: number;
}

export interface IActionAndVioDetailData {
  id: number;
  isDelete: number;
  createdDate: number;
  modifiedDate: number;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  plateNumber: string;
  idDevice: number;
  module: string;
  ip: any;
  userAgent: any;
  action: string;
  description: string;
  deviceJson: any;
  imei: any;
  userName: any;
  type: number;
  registrationCar: any;
  companyDeliverySites: ICompanyDeliverySites;
  position: {
    id: number;
    isDelete: number;
    createdDate: number;
    modifiedDate: number;
    createBy: string;
    modifiedBy: string;
    createdDateStr: string;
    modifiedDateStr: string;
    createById: number;
    modifiedById: number;
    protocol: string;
    command: string;
    deviceId: number;
    serverTime: number;
    deviceTime: number;
    fixTime: number;
    valid: boolean;
    latitude: number;
    longitude: number;
    altitude: number;
    speed: number;
    course: number;
    address: string;
    attributes: string;
    accuracy: number;
    cutcable: number;
    plateNumber: string;
    motoloi: number;
    donglaplung: number;
    donglaplungw: number;
    pinw: number;
    rfidw: number;
    saimatkhauw: number;
    mokhoaw: number;
    khoathietbi: number;
    dongdaycap: number;
    cankichhoat: number;
    trangthaithietbi: number;
    mucpin: number;
  };
  user: any;
  receiptUpdateTime: any
  violationType: any;
  addressStr: string
  source: string;
  reason: string
}

export interface IRealTimeLocationData {
  lon: number;
  deviceTime: number;
  lat: number;
  timeCover: number;
  date?: string;
}
