import { FormInstance } from "antd";
import { ILocationDetailData } from "./locationCategory";

export interface IGroupAddData {
  description: string;
  groupName: string;
  status: number;
  type: number;
  categoryPosition: {
    id: number;
  } | null;
  authorities: {
    id: number;
  }[];
}
export interface IGroupDetailData {
  id: number;
  isDelete: number;
  createdDate: number;
  modifiedDate: number;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  groupName: string;
  status: number;
  description: null;
  authorities: IAuthorityDetailData[];
  categoryPosition: ILocationDetailData;
  type: number;
}

export interface IAuthorityDetailData {
  id: number;
  isDelete: number;
  createdDate: null;
  modifiedDate: null;
  createBy: string;
  modifiedBy: string;
  createdDateStr: string;
  modifiedDateStr: string;
  createById: number;
  modifiedById: number;
  authority: string;
  description: string;
  orderId: string;
  authKey: string;
  parentId: number;
  type?: string;
}

export interface IGroupTabProps {
  dataDetail: IGroupDetailData | undefined;
  form?: FormInstance<any>;
  isEditing: boolean;
}
