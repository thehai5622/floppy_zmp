import { LoadingOutlined } from "@ant-design/icons";
import "antd/dist/reset.css";
import ReactDOM from "react-dom/client";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/lib/integration/react";
import App from "./App";
import { persistor, store } from "./redux/store";
import reportWebVitals from "./reportWebVitals";
import "./resources/css/main.scss"; // or 'antd/dist/antd.less'
import "./utils/i18n";
import React from "react";

const root = ReactDOM.createRoot(document.getElementById("root") as HTMLElement);
root.render(
  <React.StrictMode>
    <Provider store={store}>
      <PersistGate loading={<LoadingOutlined style={{ fontSize: 24 }} spin />} persistor={persistor}>
        <App />
      </PersistGate>
    </Provider>,
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
