# Tên dự án

E-LOCK MANAGEMENT SYSTEM (EMS)

## Mô tả

Dự án E-LOCK MANAGEMENT SYSTEM là hệ thống theo dõi và khóa xe. Nó bao gồm một ứng dụng di động để khóa và mở khóa xe và một CMS dựa trên web để quản lý thông tin về chìa khóa và xe cũng như theo dõi. Hệ thống đảm bảo truy cập an toàn và cung cấp khả năng theo dõi phương tiện theo thời gian thực bằng công nghệ GPS.

## Cài đặt

1. Clone repository này: git clone https://gitlab.com/avic3/e-seal
2. Di chuyển vào thư mục dự án: cd e-seal
3. Cài đặt các dependencies: npm install

## Sử dụng

- Sử dụng command `npm run start` để chạy project

- Sử dụng command `npm run build` để build project

## Tác giả

- Tên tác giả: Nguyễn Văn Huy
- Email: nvhuy166@gmail.com

## **1. Công nghệ sử dụng**

**React** 18.2.0+

**ant Design** 5.1.2+

**Typescript** 4.9.4+

**Redux** 4.2.0+

**Redux Logger** 3.0.6+

**Redux Persist** 6.0.0+

**Redux Thunk** 2.4.2+

**Leaflet** 1.9.3+

## **2. Cấu trúc thư mục**

```
src/
├── components/
├── containers/
├── redux/
├── resources/
├── services/
├── utils/
├── Routes.tsx
```

- components: Thư mục dành cho các component sử dụng chung
- containers: Thư mục dành cho các module của dự án
- redux: Dành cho redux API, slice của các module
- resources: Thư mục chứa các tài nguyên của dự án như hình ảnh, icon, fonts,....
- services: Thư mục dành cho API của các component
- utils: Thư mục chứa các file/thư mục như contans, customHook, utilFunctions,....
- Routes.tsx: File dành cho các route của project

## **3. Môi trường**

Tùy thuộc vào môi trường hiện tại, Next sẽ tự động sử dụng file env tùy thuộc theo môi trường đó. Người dùng có thể tạo một số file `.env` như sau:

- `.env`: Load trong mọi môi trường
- `.env.local`: Load trong mọi môi trường, mặc định ignore bởi git
- `.env.[mode]`: Chỉ load trong môi trường nhất định
- `.env.[mode]`.local: Chỉ load trong môi trường nhất định, mặc định ignore bởi git

Các tệp `_.local` (ví dụ: `.env.local`,` .env.development.local`) có thể được sử dụng để ghi đè các biến môi trường đã được định nghĩa trong các tệp `.env` tương ứng. Điều này cho phép bạn ghi đè các biến môi trường trong các môi trường cụ thể mà không làm thay đổi các tệp `.env` gốc. Tuy nhiên, các biến trong các tệp `_.local` vẫn không được ưu tiên hơn biến trong tệp `.env`.

---

## **4. Một số lưu ý**

### 4.1. Cách thêm một module mới

Để thêm một module mới, thêm một thư mục tương ứng vào trong thư mục `containers/` và một file `.scss`tương ứng vào `resources/css/`

```
├──containers/
│ ├── dashboard/
│ │   ├── components/
│ │   └── index.tsx
├── resources/
| ├── css/
│ │   ├── dashboard.scss
```

### 4.2. Cách thêm một Slice mới

Với các module phức tạp, cần sử dụng Redux để quản lý state ta thực hiện các bước như sau:

1.  Tạo một file constanst trong thư mục `src/redux/constants`.

```typescript
// profile.constants.ts
export const SAVE_PROFILE = "SAVE_PROFILE";
```

2.  Tạo một file Slice tương ứng trong thư mục `src/redux/actions`.

```typescript
// profile.actions.ts
import * as Constants from "../constants/profile.constants";

export const saveProfile = (payload: any) => {
  return {
    type: Constants.SAVE_PROFILE,
    payload: payload,
  };
};
```

3.  Tạo một file Reducer tương ứng trong thư mục `src/redux/reducers` và sử dụng `combineReducers` để nhóm các Reducer vào thành một Reducer duy nhất (`rootReduce`) trong file `index.js`.

```typescript
// profile.reducer.ts
import * as Constants from "../constants/profile.constants";

const initialState = {
  profile: null,
};

export default function (state = initialState, action: any) {
  switch (action.type) {
    case Constants.SAVE_PROFILE:
      return {
        ...state,
        profile: action?.payload,
      };
    default:
      return state;
  }
}
```

```typescript
// index.js
import { combineReducers } from "redux";

import profileReducer from "./profile.reducer";
import globalReducer from "./global.reducer";
import positionsReducer from "./positions.reducer";
import positionSelectedReducer from "./positionSelected.reducer";

const rootReducer = combineReducers({
  globalReducer,
  profileReducer,
  positionsReducer,
  positionSelectedReducer,
});

export default rootReducer;
```

4.  Sau đó tiến hành cấu hình trong file `store`.

```typescript
// store.js
import { legacy_createStore as createStore, applyMiddleware } from "redux";
import thunkMiddleware from "redux-thunk";
import { createLogger } from "redux-logger";
import storage from "redux-persist/lib/storage"; // defaults to localStorage for web
import { persistStore, persistReducer } from "redux-persist";

import rootReducer from "./reducers";

const persistConfig = {
  key: "reducer",
  storage: storage,
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

const loggerMiddleware = createLogger();

export const store = createStore(
  persistedReducer,
  applyMiddleware(thunkMiddleware, loggerMiddleware),
);
export const persistor = persistStore(store);
```

Các thao tác với state bao gồm:

```typescript
// Lấy redux state
// profileReducer được khai báo trong danh sách reducer ở trên
const { profile } = useSelector((state: any) => state?.profileReducer);
const authorities = profile.authorities; // Lấy biến authorities trong profile

// Dispatch action
const dispatch = useAppDispatch();
dispatch(saveProfile(null)); // Đặt profile thành null
```

### 4.3 Tạo biến trong variable.scss

- File `variable.scss` chứa các biến của dự án nó tỷ lệ với màn viewport width = **1920px**
- Các biến được đặt theo định dạng: `$px<số pixel>: <số pixel sau khi đổi>vw`. ví dụ: `$px10: 0.521vw`
- Có thể [click vào đây](https://www.quick-tools.net/10px-to-vw-1920vp) để dùng công cụ chuyển đơn vị từ `px` sang `vw`
